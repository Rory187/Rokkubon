from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Collecting information from the form
        employee_number = request.form.get('employee_number')
        table_number = request.form.get('table_number')

        # Create a dictionary to store the ordered items and their quantities
        ordered_items = {}
        for item in ['sushi', 'miso-soup', 'teriyaki', 'salmon_roll', 'salad', 'mochi']:
            quantity = request.form.get(item, type=int)
            ordered_items[item] = quantity

        # Printing the information to the console
        print("EMPLOYEE NUMBER:", employee_number)
        print("TABLE NUMBER:", table_number)
        print("ORDERED ITEMS WITH QUANTITIES:", ordered_items)

    return render_template('home.html')



@app.route('/order')
def order():
    return render_template('home.html')

if __name__ == '__main__':
    app.run(debug=True)
