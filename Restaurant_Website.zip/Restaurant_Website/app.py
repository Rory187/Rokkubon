# --------------------------------------------------------------------------------------

from flask import Flask, render_template, request
from sqlalchemy import create_engine, MetaData, Table, select
import psycopg2
import pandas as pd
from email_sender import email_send
# --------------------------------------------------------------------------------------
# Initialising the application
app = Flask(__name__)
# --------------------------------------------------------------------------------------
# Home Page
@app.route('/')
def home():
    return render_template('index.html')
# --------------------------------------------------------------------------------------
# Menu Page
@app.route('/menu')
def menu():
    return render_template('menu.html')
# --------------------------------------------------------------------------------------
# Feedback Page
@app.route('/feedback' , methods=['GET','POST'])
def feedback():
    if request.method == 'POST':
        rating1 = int(request.form.get('rating'))
        rating2 = int(request.form.get('rating2'))


        print('this is the rating:\n\n',rating1,rating2)
    return render_template('feedback.html')
# --------------------------------------------------------------------------------------
# Bookings Page
@app.route('/bookings', methods=['GET','POST'])
def bookings():
    invalid_booking = False
    if request.method == 'POST':
        # --------------------------------------------------------------------------------------
        # Collecting all details from booking form
        firstName = request.form.get('firstName')
        lastName = request.form.get('lastName')
        email = request.form.get('email')
        numberOfPeople = request.form.get('Number of People')
        date = request.form.get('dateTime').split('T')[0]
        time = request.form.get('dateTime').split('T')[1]
        message = request.form.get('message')
        
        print(firstName,lastName,email,numberOfPeople,date,time,message)
        # --------------------------------------------------------------------------------------
        # Create dataframe of the booking details
        bookings_df = pd.DataFrame({
                                    'firstname':[firstName],
                                   'lastName':[lastName],
                                   'email':[email],
                                   'numberOfPeople':[numberOfPeople],
                                   'date':[date],
                                   'time':[time],
                                   'message':[message]})
        # --------------------------------------------------------------------------------------
        # Database connection details
        db_server = 'rokkubon-server.postgres.database.azure.com'
        db_name = 'rokkubon_db'
        db_user = 'rokkubon'
        db_password = 'W!nners123'

        
        # Create the SQLAlchemy engine
        engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_server}/{db_name}')

        # Establish a connection using psycopg2
        conn = psycopg2.connect(
            host=db_server,
            database=db_name,
            user=db_user,
            password=db_password
        )

        
        # Create a cursor
        cursor = conn.cursor()
        # --------------------------------------------------------------------------------------
        # Specify the table
        table_name = 'bookings'  

        # Check availability
        query = f"SELECT * FROM {table_name} where date = '{date}' AND time = '{time}'"
        cursor.execute(query)
        
        # Return all rows that match this query
        rows = cursor.fetchall()
        print('Result of query: ',rows)
        # --------------------------------------------------------------------------------------

        # Check capacity
        capacity = 5

        # If there's space add booking to table and send confirmation email
        if len(rows) < capacity:
            # Booking added to 'bookings' table 
            bookings_df.to_sql(table_name, engine, if_exists='append', index=False)
            # Sending confirmation email
            email_send(f'Booking has been SUCCESSFUL!\nName: {firstName} {lastName}\nNumber Of People: {numberOfPeople}\nDate & Time: {date} : {time}','Booking Confirmation',email)

        else:
            invalid_booking = True
            print('Too full!')
        # --------------------------------------------------------------------------------------

        # Close the database connection
        engine.dispose()

    return render_template('booking.html',invalid_booking=invalid_booking)
    
        
# --------------------------------------------------------------------------------------
# Contact Us Page
@app.route('/contact')
def contact():

    return render_template('contact.html')

# --------------------------------------------------------------------------------------
if __name__ == '__main__':
    app.run()


