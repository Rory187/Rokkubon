# ------------------------------------------------------------------
# Imports
import smtplib
from email.mime.text import MIMEText
# ------------------------------------------------------------------
# Sends email
def email_send(body,subject,recipient_email):
        sender = "george.benjamin.lopez@gmail.com"
        recipient = recipient_email

        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = sender
        msg["To"] = recipient

        with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.login("george.benjamin.lopez@gmail.com", "mwosovmfocqspvbq")
            smtp.sendmail(sender, [recipient], msg.as_string())
# ------------------------------------------------------------------
